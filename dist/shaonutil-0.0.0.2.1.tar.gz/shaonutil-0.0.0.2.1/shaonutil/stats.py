def mean(li):
	return sum(li)/len(li)

if __name__ == '__main__':
	pass