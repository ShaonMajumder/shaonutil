def mean(li):
	return sum(li)/len(li)
